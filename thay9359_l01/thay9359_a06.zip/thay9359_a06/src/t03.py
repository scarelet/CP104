"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""

from functions import interest_table
result = interest_table(750, 8.5, 200)
print(result)