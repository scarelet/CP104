"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import count_of_digits
result = count_of_digits(-1024)


  
print(result)  
