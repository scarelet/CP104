"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-11"
-------------------------------------------------------
"""
from functions import factor_summation
result =factor_summation(9)
print(result)  