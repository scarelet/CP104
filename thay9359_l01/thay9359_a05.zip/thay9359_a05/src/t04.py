"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""

#import from functions
from functions import multiplication_table
multiplication_table(2, 4) #input the numbers here
