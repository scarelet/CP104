"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-04"
-------------------------------------------------------
"""
#import from functions
from functions import calories_treadmill
calories_treadmill(4.1, 20) # input your numbers here to the corresponding parameters
