"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""

from functions import add_spaces

# Call the add_spaces function
spaced_sentence = add_spaces('StopAndSmellTheRoses.')

# Print the result
print(spaced_sentence)