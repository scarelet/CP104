"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""

from functions import verify_sorted

lists = [1, 2, 3, 4, 5]
sorted, unsorted = verify_sorted(lists)
print(f"List {lists} is sorted: {sorted}, First unsorted index: {unsorted}")