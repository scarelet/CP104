"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""

from functions import get_indexes


numbers_list = [5, 1, 8, 9, 5, 2, 5, 3]
target = 5
result = get_indexes(numbers_list, target)


print("Indexes of", target, "in", numbers_list, "->", result)