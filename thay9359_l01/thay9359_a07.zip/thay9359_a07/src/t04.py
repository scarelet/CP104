"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-18"
-------------------------------------------------------
"""


from functions import list_subtract


minuend_list = [5, 5, 4, 5]
subtrahend_list = [5]

print(minuend_list)
list_subtract(minuend_list, subtrahend_list)
print("minuend after:", minuend_list)