"""
-------------------------------------------------------
Midterm A Task 3 Function Definitions
-------------------------------------------------------
Author: Navina Thayaruban
ID:     169069359
Email:  thay9359@mylaurier.ca
__updated__ = "2023-10-29"
-------------------------------------------------------
"""
# Constants

# your constants here


def servicing():
    """
    -------------------------------------------------------
    Determines the cost of getting a car cleaned. The cost is made up of:
        base cost: $95.00
        cost per extra service: $35.00
        VIP discount 15% only if:
            more than 1 extra service purchased
            and purchaser is a VIP
    The function must ask the user for these inputs.
    Use: cost = servicing()
    -------------------------------------------------------
    Returns‌​‌​​​​‌​​‌‌‌‌​​‌​‌‌​​‌​‌‌‌‌:
        cost - cost of cleaning a car based upon the base cost,
            the number of extra services purchased, and VIP discount
            if applicable (float)
    -------------------------------------------------------
    """

    SERVICE_CHARGE = 95.00
    EXTRA_SERVICE_CHARGE = 35.00
    DISCOUNT_PERCENTAGE = 15
    EXTRA_SERVICE = 1
    
    
    extra_services = int(input("How many extra services are you purchasing?"))
    vip = input("Are you a VIP member (Y/N)? ")
    is_vip = vip == 'y'
    
    cost = SERVICE_CHARGE +(extra_services * EXTRA_SERVICE_CHARGE)
    
    if extra_services >  EXTRA_SERVICE and is_vip: 
        discount = (cost * DISCOUNT_PERCENTAGE) / 100
        cost -= discount 
        
    return cost 
    