"""
-------------------------------------------------------
Midterm A Task 4 Testing
-------------------------------------------------------
Author: Navina Thayaruban
ID:     169069359
Email:  thay9359@mylaurier.ca
__updated__ = "2023-10-29"
-------------------------------------------------------
"""
from t04_functions import result 

test = result('Win')
print("Test one: (response is: 'Win'): ", test) 

test_2 = result('Loss')
print("Test two: (response is: 'Loss'): ", test_2) 

test_3 = result('Draw')
print("Test three: (response is: 'Draw'): ", test_3) 

