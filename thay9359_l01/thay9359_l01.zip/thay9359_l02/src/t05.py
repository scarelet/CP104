"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-19"
-------------------------------------------------------
"""

#Inputs
pay = float(input("Hourly rate of pay: $ "))
hours = float(input("Hours worked in the week: "))

#Calculations
# Total amount of weekly pay
weekly_pay = pay * hours
#Output
print(" Total pay for the week :$ ", weekly_pay )