"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""
#Constant
FARENHEIT_FREEZING = 32
FTOC = 5/9

#Input
fahrenheit = int(input("Temperature(F): "))
#Calculations
#Celsius to Fahrenheit
celsius  = (fahrenheit - FARENHEIT_FREEZING) * FTOC

#Output
print("Temperature (C): ", celsius)