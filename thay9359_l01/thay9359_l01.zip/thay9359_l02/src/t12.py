"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""
#Constants
#Inputs
SECONDS = int(input("Number of seconds: "))
HOURS_TO_S = 60
SECONDS_PER_MIN = 60

#Calculations
#Conversion from seconds to days 
days = SECONDS // (24* HOURS_TO_S * SECONDS_PER_MIN )
#Converting reminder seconds to hours
rem_seconds = SECONDS % (24* HOURS_TO_S * SECONDS_PER_MIN )
hours = rem_seconds // (HOURS_TO_S * SECONDS_PER_MIN) 
#Converting remainder seconds to minutes
rem_seconds %= (HOURS_TO_S * SECONDS_PER_MIN) 
minutes = rem_seconds // 60

#Leftover seconds
final_seconds = rem_seconds % 60

#Output
print("Days: ", days, "Hours: ", hours, "Minutes: ", minutes, "Seconds: ",final_seconds)
