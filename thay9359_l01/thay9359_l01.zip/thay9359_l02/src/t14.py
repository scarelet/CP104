"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-20"
-------------------------------------------------------
"""
#Input
#Constant
SERVINGS = int(input("Enter servings of Mac & Cheese:"))
MILK = 4/ 6
BUTTER = 8/6
FLOUR = 0.5/6
SALT = 2/6

#Calculations
# TODO: calculate amount of servings for the following items
milk1 = MILK * SERVINGS
butter1 = BUTTER * SERVINGS
flour1 = FLOUR * SERVINGS
salt1 = SALT * SERVINGS

#Output
print(SERVINGS, "servings of Mac & Cheese requires:")
print ( "milk(cups)",milk1)
print( "butter (tablespoons): ", butter1)
print("flour (cups): ", flour1)
print("salt (teaspoons): ",salt1)
