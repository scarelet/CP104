"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-19"
-------------------------------------------------------
"""


#Input 
#Constant
MORTGAGE_PRINCIPALS = float(input("Mortgage principal ($): "))
YEARS = int(input("Number of years: "))
YEARLY_INTEREST_RATE = float(input("Yearly interest rate (%): "))
                           
#Calculations
# TODO: calculate yearly interest rate for one month
interest_rate = (YEARLY_INTEREST_RATE /100)/12
#TODO: calculate the amount of years to months 
number_months = int(YEARS * 12 )

#TODO: calculate total monthly payments
monthly_payments = (interest_rate* MORTGAGE_PRINCIPALS*((1+interest_rate)**number_months))/(((1+interest_rate)**number_months)-1)

#Output
print( "The monthly payments are: $" ,monthly_payments)