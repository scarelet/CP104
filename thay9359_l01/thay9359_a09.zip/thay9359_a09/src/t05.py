"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""

from functions import student_stats
with open("students.txt", "r", encoding="utf-8") as file_handle:
    l_id, h_id, avg = student_stats(file_handle)


print("Lowest ID:", l_id)
print("Highest ID:", h_id)
print("Average Mark:", avg)