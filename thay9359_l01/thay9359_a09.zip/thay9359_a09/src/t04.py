"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""


from functions import line_numbering

read = open("wilde.txt", "r", encoding="utf-8")
write = open("wilde_numbered.txt ", "w", encoding="utf-8")
line_numbering(read, write)
print("Success")
print()


    
    