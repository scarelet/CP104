"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""
from functions import file_top

fh = open("students.txt", "r", encoding="utf-8")

print(file_top(fh, 5))