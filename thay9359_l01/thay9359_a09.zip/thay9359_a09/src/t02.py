"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""

from functions import read_integers  

file_handle = open("numbers.txt", "r", encoding="utf-8")


result = read_integers(file_handle)
print(result)

file_handle.close()