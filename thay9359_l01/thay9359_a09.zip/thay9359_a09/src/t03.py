"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-02"
-------------------------------------------------------
"""

from functions import file_statistics

file_handle = open("addresses.txt", "r", encoding="utf-8")

file = open("addresses.txt", "r", encoding="utf-8")
ucount, lcount, dcount, wcount, rcount = file_statistics(file_handle)
print(f"Upper-case letters: {ucount}")
print(f"Lower-case letters: {lcount}")
print(f"Digits: {dcount}")
print(f"White-space characters: {wcount}")
print(f"Remaining characters: {rcount}")
print()