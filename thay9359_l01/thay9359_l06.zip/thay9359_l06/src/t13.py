"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-23"
-------------------------------------------------------
"""
from functions import lumber
b_min = int(input("minimum value of base: "))
b_max = int(input("maximum value of base: "))
b_inc = int(input("increment in base value: "))
h_min = int(input("minimum value of height: "))
h_max = int(input("maximum value of height: "))
h_inc = int(input("increment in height value: "))


print(lumber(b_min, b_max, b_inc, h_min, h_max, h_inc))
