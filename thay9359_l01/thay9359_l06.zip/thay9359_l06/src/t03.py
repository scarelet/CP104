"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-23"
-------------------------------------------------------
"""
# Imports

# Constants
from functions import sum_all
start = int(input("What number do you want to start off with?: "))
finish = int(input("What number do you want to end with?: "))
increment = int(input("What number do you want to go up by?: "))

print(sum_all(start, finish, increment))