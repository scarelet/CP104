"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-23"
-------------------------------------------------------
"""
# Imports

# Constants
def sum_all(start, finish, increment):
    """
    -------------------------------------------------------
    Sums and returns all numbers from start to finish (inclusive)
    by increment.
    Use: total = sum_all(start, finish, increment)
    -------------------------------------------------------
    Parameters:
        start - an integer (int > 0)
        finish - an integer (int >= start)
        increment - an integer (int > 0)
    Returns:
        total - sum of all numbers from start to
            finish by increment (int)
    ------------------------------------------------------
    """

    total = 0
    for i in range(start, finish +1 , increment):
        total += i
    return total
    

def draw_hollow_triangle(width, char):
    """
    -------------------------------------------------------
    Prints a hollow triangle of width characters using
    the char character.
    Use: draw_hollow_triangle(width, char)
    -------------------------------------------------------
    Parameters:
        width - number of characters wide (int > 0)
        char - the character to draw with (str, len() == 1)
    Returns:
        None
    ------------------------------------------------------
    """
   
    print(char)
    if width > 1:
        for i in range(width -2):
            print("{}{}{}". format(char, " "* i, char))
        for i in range(width):
                print("{}".format (char), end="")
    print()
    return
        
        
def retirement(age, salary, increase):
    """
    -------------------------------------------------------
    Calculates a prints a table of how much a worker earns
    between age and retirement at 65.
    Use: retirement(age, salary, increase)
    -------------------------------------------------------
    Parameters:
        age - worker's current age (int > 0)
        salary - worker's current salary (float > 0)
        increase  percent increase in salary per year (float >= 0)
    Returns:
        None
    ------------------------------------------------------
    """
   
    print('Age         Salary')
    print('==================')
    
    if age <= 0 or salary <= 0 or increase <0: 
        print('Invalid input, please enter valid values. ')
        return 
    
    for i in range(age, 66):
        print(f"{age}      {salary:10,.2f}")
        salary += salary * (increase / 100)
        age = age + 1

    
    
        
def lumber(b_min, b_max, b_inc, h_min, h_max, h_inc):
    """
    -------------------------------------------------------
    Create a table of the engineering properties of lumber.
    Given the base and height of a piece of lumber in inches,
    different properties of a piece of lumber are calculated as:
        cross-sectional area = base × height
        moment of inertia = base × height^3 / 12
        section modulus = base × height^2 / 6
    Use: lumber(b_min, b_max, b_inc, h_min, h_max, h_inc)
    -------------------------------------------------------
    Parameters:
        b_min - minimum value of base (int > 0)
        b_max - maximum value of base (int > b_min)
        b_inc - increment in base value (int > 0)
        h_min - minimum value of height (int > 0)
        h_max - maximum value of height (int > h_min)
        h_inc - increment in height value (int > 0)
    Returns:
        None
    -------------------------------------------------------
    """
    print(f"               Cross Sectional   Moment of  Section")
    print(f"Base  Height   Area               Inertia   Modulus")
    print(f"---------------------------------------------------")

    for base in range(b_min, b_max + b_inc, b_inc):
        for height in range(h_min, h_max + h_inc, h_inc):
           
            area = base * height
            inertia = (base * height**3) / 12
            modulus = (base * height**2) / 6
            print(
                f"{base:>3d}  x   {height:3d}{area:>17.2f}{inertia:>11.2f}{modulus:>11.2f}")
    return
    
def ia_hours(ia_count):
    """
    -------------------------------------------------------
    Calculates the total number of hours that IAs (Instructional
    Assistants) work over a 6 week period by asking for the hours
    for each IA per week.
    Use: total_hours = ia_hours(ia_count)
    -------------------------------------------------------
    Parameters:
        ia_count - number of IAs (int > 0)
    Returns:
        total_hours - hours worked by all IAs (float)
    ------------------------------------------------------
    """
    NUMBER_OF_WEEKS = 6
    total_hours = 0.0  # Initialize the total hours to 0.0

    # Iterate over the 6 weeks
    for week in range(1, NUMBER_OF_WEEKS +1):
        print(f"Week {week}")
        
        # Iterate over each IA
        for ia in range(1, ia_count + 1):
            ia_hours_week = float(input(f"  Marking hours for IA {ia}: "))
            total_hours += ia_hours_week  # Add the IA's hours to the total
            print(f"\nTotal hours worked by all IAs : {total_hours:.2f}")

    return total_hours
        
        
        
    