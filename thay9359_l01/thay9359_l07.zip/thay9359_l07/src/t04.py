"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-02"
-------------------------------------------------------
"""

from functions import sum_squares
print(sum_squares(26))