"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359
__updated__ = "2023-10-31"
-------------------------------------------------------
"""
from random import randint

def hi_lo_game(high):
    """
    -------------------------------------------------------
    Plays a random higher-lower guessing game.
    Use: count = hi_lo_game(high)
    -------------------------------------------------------
    Parameters:
        high - maximum random value (int > 1)
    Returns:
        count - the number of guesses the user made (int)
    -------------------------------------------------------
    """
   
    number = randint(1, high)
    count = 0

    while True:
        guess = int(input("Guess: "))
        count = count+ 1

        if guess < number:
            print("Too low, try again.")
        elif guess > number:
            print("Too high, try again")
        else:
            print("Congratulations - good guess!")
            break
    print(f"You made {count} guesses.")
    
    return count



def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    power = 1  # Initialize power to 2^0
    while power < target:
        power *= 2  # Double the power until it's greater than or equal to the target
    return power

def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """
    
    final = 0
    n = 0 
    while final <= target: 
        n +=1 
        final+= n * n 
        
    return final 

def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    ------------------------------------------------------
    """

    status = ""
    expenses = float(input("Enter an expense (0 to quit): $"))
    balance = 0.0
    x = 1

    while x == 1: 
        money = float(input("Enter another expense (0 to quit): $"))
        if money == 0:
            break  # Exit the loop if the user enters 0
        
        expenses += money
        balance -= money

    if balance > expenses:
        status = "Surplus"
    elif balance == expenses:
        status = "Balance"
    else:
        status = "Deficit"

    return expenses, balance, status
    
    
    
def employee_payroll():
    """
    -------------------------------------------------------
    Calculates and returns the weekly employee payroll for all employees
    in an organization. For each employee, ask the user for the employee ID
    number, the hourly wage rate, and the number of hours worked during a week.
    An employee number of zero indicates the end of user input.
    Each employee is paid 1.5 times their regular hourly rate for all hours
    over 40. A tax amount of 3.625 percent of gross salary is deducted.
    Use: total, average = employee_payroll()
    -------------------------------------------------------
    Returns:
        total - total net employee wages (i.e. after taxes) (float)
        average - average employee net wages (float)
    ------------------------------------------------------
    """
    
    
    RATE = 1.5
    TAX = 0.03625
    MIN_TO_HOUR = 40

    count = 0
    total = 0

    id = int(input("Enter ID: "))
    
    while id != 0:
        wage = float(input("Enter hourly wage: "))
        hours = float(input("Enter hours worked: "))

        if hours > MIN_TO_HOUR:
            regular_pay = MIN_TO_HOUR * wage
            overtime = (hours - MIN_TO_HOUR) * wage * RATE
            salary = regular_pay + overtime
        else:
            salary = hours * wage

        tax_amount = TAX * salary
        net = salary - tax_amount

        print(f"Net payment for employee {id}: ${net:.2f}")

        total += net
        count += 1

        id = int(input("Enter ID (0 to quit): "))

    if count == 0:
        average = 0
    else:
        average = total / count

    return total, average

        
            
            
            
            
    
    