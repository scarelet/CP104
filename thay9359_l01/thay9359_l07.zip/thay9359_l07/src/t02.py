"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-02"
-------------------------------------------------------
"""
from functions import power_of_two

# Sample execution
print(power_of_two(3))   # Should print 4
print(power_of_two(4))   # Should print 4
print(power_of_two(248)) # Should print 256






