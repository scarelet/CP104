"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""

breakfast = float(input("Enter cost of breakfast: $"))
lunch = float(input("Enter a cost of lunch: $"))
supper = float(input("Enter cost of supper: $"))

total = breakfast + lunch +supper


   
print(f" Meal         Cost")
print(f"Breakfast   ${breakfast:6.2f}")
print(f"Lunch       ${lunch:6.2f}")
print(f"Supper      ${supper:6.2f}")
print(f"Total       ${total:6.2f}")

                 
