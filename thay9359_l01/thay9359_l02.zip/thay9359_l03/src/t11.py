"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""
location1 = "left"
location2 = "middle"
location3 = "right"

print(f"{location1:-<20s}")
print(f"{location2:-^20s}")
print(f"{location3:->20s}")
