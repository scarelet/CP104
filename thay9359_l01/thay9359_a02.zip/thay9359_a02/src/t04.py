"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
#Input

flyers = int (input ("Enter number of flyers: " ))
delivery_people = int (input ("Enter number of delivery people: " ))
#Calculation
#Divide the amount of flyers by the amount of delivery people
delivery_per_person = flyers // delivery_people
#Takes the remainder 
leftover =  flyers % delivery_per_person 
print(f"Flyers per delivery person: {delivery_per_person}")
print(f"Flyers left over: {leftover}")
