"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
#Input
flength = float(input("Foundation length (m): "))
fwidth = float(input("Foundation width (m): "))
fheight = float(input("Foundation height (m): "))
wheight = float(input("Wall height (m): " ))
concrete = float(input("Cost of concrete ($/m^3): "))
brick = float(input("Cost of bricks ($/m^2): "))

#Calculation
total_concrete = flength * fwidth * fheight 
perimeter = 2 * (flength + fwidth)
area_for_wall = perimeter * wheight

cost_concrete = total_concrete *concrete
brick_cost = area_for_wall* brick
total_cost = cost_concrete + brick_cost
#Output
print(f"Concrete needed for foundation (m^3) {total_concrete:.2f} ")
print(f"Cost of concrete ${cost_concrete:.2f}")
print(f"Bricks needed for walls (m^2): {area_for_wall:.2f} ")
print(f"Cost of bricks: ${ brick_cost:.2f}")
print(f"Total cost: $ {total_cost:.2f} ")
