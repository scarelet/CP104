"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
#Constant 
TAX_RATE = 18.50
tax_rate = 18.50/100
#Input
sales = float(input("Enter the amount of sales: $"))
#Calculation 
# annual tax by multiplying the sales by the tax rate as a percent
tax = sales * tax_rate

#Output 
print("Projected Tax Report")
print(f"-----------------------")
print (f"Total sales:   ${sales}")
print (f"Annual tax:    %{TAX_RATE:.2f}")
print(f"-----------------------")
print (f"Tax:           ${tax:.2f} ")