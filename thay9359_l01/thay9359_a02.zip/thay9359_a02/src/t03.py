"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
#Input
date = int(input( "Enter a date in the format YYYYMMDD: "))
#Extract the number to properly format the date
year = date//10000
month = (date // 100) % 100
day = date % 100
#Output 
#Print into the proper format 
print(f"{year}/{month}/{day}")
