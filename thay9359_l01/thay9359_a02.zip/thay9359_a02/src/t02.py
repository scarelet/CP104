"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-04"
-------------------------------------------------------
"""
#Input
number = int(input ("Enter a positive digit number: "))
#Calculations 
#extracts  the first digit from the 2 digit 
tens = (number // 10)
ones = (number % 10)
#subtract the two numbers 
difference = ( tens - ones )
#Output
print(f"The difference of the digits of {number} is {difference}")