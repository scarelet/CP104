"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""

from functions import many_search

result = many_search([94, 96, -22, -79, -28, 96, -50, 71, 24, -32], 96)
print(result)
