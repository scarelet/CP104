"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""

from functions import get_digit_name
 

result = get_digit_name(2)
print(result)