"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""


from functions import list_stats

result = list_stats([94, 96, -22, -79, -28, -26, -50, 71, 24, -32])
print(result)



