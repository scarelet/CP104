"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""

from functions import intersection 

result = intersection([10, 3, 10, 3, 1], [8, 2, 7, 3, 6, 10, 32, 99])
print(result)