"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-10"
-------------------------------------------------------
"""

from functions import list_sums

result = list_sums([10, 3, 10, 3, 1], [8, 2, 7, 3, 6])
print(result)