"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-17"
-------------------------------------------------------
"""

from functions import falling_distance

#Input
falling_time = int(input("Enter distance in metres: "))

#Output
print(falling_distance(falling_time))