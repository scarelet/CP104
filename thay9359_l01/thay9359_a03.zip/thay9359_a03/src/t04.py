"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-17"
-------------------------------------------------------
"""

from functions import multiply_fractions
#Input
num1 = int(input("Enter numerator 1: "))
den1 = int(input("Enter denominator 1: "))
num2 = int(input("Enter numerator 2: "))
den2= int(input("Enter denominator 2: "))

#Output
print(multiply_fractions(num1, den1, num2, den2))