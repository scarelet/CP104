"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-17"
-------------------------------------------------------
"""

from functions import lawn_mow_time
#Input 
width = float(input("Width of  lawn in meters: ")) 
length = float(input("Length of lawn in meters: ")) 
speed = float(input("Speed (sq m: ")) 

#Output

print(lawn_mow_time(width, length, speed))