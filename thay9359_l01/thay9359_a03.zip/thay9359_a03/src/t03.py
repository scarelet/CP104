"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-17"
-------------------------------------------------------
"""

from functions import extract_date
#Input 
date_number = int(input( "Enter a date in the format YYYYMMDD: "))

#Output
print(extract_date(date_number))
