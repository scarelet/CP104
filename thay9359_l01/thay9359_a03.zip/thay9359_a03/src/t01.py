"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:  thay9359@mylaurier.ca
__updated__ = "2023-10-17"
-------------------------------------------------------
"""

from functions import footage_to_acres
#Input 
square_feet = float(input("Enter in square feet: "))


#Output
print(footage_to_acres(square_feet))
