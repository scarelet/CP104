"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""

from functions import file_copy

fh1 = open("words.txt", "r", encoding="utf-8")

fh2 = open("new_words.txt", "w", encoding="utf-8")

print(file_copy(fh1, fh2))