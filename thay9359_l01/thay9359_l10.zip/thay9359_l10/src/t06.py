"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""

from functions import number_stats

fh = open("numbers.txt", "r", encoding="utf-8")

print(number_stats(fh))