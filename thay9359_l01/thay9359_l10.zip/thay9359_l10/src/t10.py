"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-24"
-------------------------------------------------------
"""

from functions import count_frequency_word

fh = open("words.txt", "r", encoding="utf-8")

word = " "

print(count_frequency_word(fh, 'Exercise'))

