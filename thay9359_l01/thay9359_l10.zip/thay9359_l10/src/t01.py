"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-23"
-------------------------------------------------------
"""

from functions import customer_record

fh = open("customers.txt", "r", encoding="utf-8")

print(customer_record(fh, 9))

