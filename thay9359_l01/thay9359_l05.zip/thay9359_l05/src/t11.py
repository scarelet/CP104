"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""

from functions import quadrant
#Input
x = float(input("Enter x coordinate on a Cartesian plane (float): "))
y = float(input("Enter y coordinate on a Cartesian plane (float): "))
#Output
print(quadrant(x,y))



