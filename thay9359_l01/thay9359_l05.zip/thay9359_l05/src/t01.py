"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""

 
from functions import magic_date 

#Input
day = int(input("Enter day: "))
month = int(input("Enter month: "))
year = int(input("Enter year: "))

#Prints output
print(magic_date(day, month, year))

