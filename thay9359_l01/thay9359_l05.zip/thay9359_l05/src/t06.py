"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-10-16"
-------------------------------------------------------
"""

from functions import is_divisible
#Input
n = int(input("Enter a number to check for divisibility: "))
i  = int(input("one of the values to divide n by: " ))
j = int( input("one of the values to divide n by: "))

#Output
print(is_divisible(n, i, j))
