"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""
#Input
#Constant
PRINCIPAL = float(input( "Principal: $"))
INTEREST = float(input( "Interest(%): "))
YEARS = int(input("Number of years:"))
COMPOUND = int(input("Number of times interest compound: "))

#Makes the interest into a decimal
interest = (INTEREST /100)
#Calculation 
#Compound interest equation
balance = PRINCIPAL*( 1 +(interest/ COMPOUND))** (COMPOUND * YEARS)
#Output
print("Balance: $", balance)
