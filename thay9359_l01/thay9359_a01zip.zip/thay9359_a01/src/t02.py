"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""
#Input
#Constant
AGE = int(input("What is your age?: "))
BAND = input("What is your favourite band?")

#Output 
#Input the age and band in the sentence.
print(f"I am {AGE} years old and {BAND} is my favourite band.")
