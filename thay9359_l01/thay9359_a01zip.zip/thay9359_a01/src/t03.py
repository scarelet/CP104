"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""
#Input
#Constant 
CONVERSION_FACTOR = 1.61
MILES = float(input("Length in miles: "))
#Calculation 
#Conerts kilometres to miles
kilometres = CONVERSION_FACTOR * MILES

#Output
print("Length in km: ", kilometres)
