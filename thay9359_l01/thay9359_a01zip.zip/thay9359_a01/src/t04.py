"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thaya9359@mylaurier.ca
__updated__ = "2023-09-25"
-------------------------------------------------------
"""
#Input 
#Constant
COST = float(input("Cost of 1 dosa : $"))
AMOUNT = int(input(" Number of dosa:" ))
#Calculation
#Calculating total amount by price and the amount of dosas
total = COST * AMOUNT 
#Output
print(f"Total cost of {AMOUNT} dosas: $", total)