"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-13"
-------------------------------------------------------
"""

from functions import text_analyze

result = text_analyze('Python uses whitespace indentation, rather than curly brackets or keywords, to delimit blocks.')
print(result)