"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-13"
-------------------------------------------------------
"""

from functions import password_strength

result = password_strength('1234')
print(result)

