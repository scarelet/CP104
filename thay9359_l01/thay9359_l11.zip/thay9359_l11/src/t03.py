"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""

from functions import print_matrix_num




matrix = [
    [9, 8, 7],
    [6, 5, 4],
    [3, 2, 1]
]

value_type = 'int'
print_matrix_num(matrix, value_type)