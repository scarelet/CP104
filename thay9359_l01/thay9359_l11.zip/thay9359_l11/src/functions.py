"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""

import random 
def generate_matrix_num(rows, cols, low, high, value_type):
    """
    -------------------------------------------------------
    Generates a 2D list of numbers of the given type, 'float' or 'int'.
    (To generate random float number use random.uniform and to
    generate random integer number use random.randint)
    Use: matrix = generate_matrix_num(rows, cols, low, high, value_type)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the list (int > 0)
        cols - number of columns (int > 0)
        low - low value of range (float)
        high - high value of range (float > low)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        matrix - a 2D list of random numbers (2D list of float/int)
    -------------------------------------------------------
    """
    
    
    matrix = []
    
   
    for i in range(rows):
        row = []
        
        for j in range(cols):
           
            if value_type == 'float':
                value = random.uniform(low, high)
                
            elif value_type == 'int':
                value = random.randint(low, high)
                
            else:
                value = 0
            
       
            row.append(value)
            
        matrix.append(row)
        
    return matrix



def print_matrix_num(matrix, value_type):
    """
    -------------------------------------------------------
    Prints the contents of a 2D list in a formatted table.
    Prints float values with 2 decimal points and prints row and
    column headings.
    Use: print_matrix_num(matrix, 'float')
    Use: print_matrix_num(matrix, 'int')
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of values (2D list)
        value_type - type of values in the list, 'float' or 'int' (str)
    Returns:
        None.
    -------------------------------------------------------
    """
    
   
    if not matrix: 
        print("No values")
    
   
    else:
       
        print(f"{' ':>3}", end = "")
        for col in range(len(matrix[0])):
            print(f"{col + 0:5}", end = "")
        print()    
        
        for row_index, row in enumerate(matrix):
            print(f"{row_index + 0:2} ", end = "")
            
           
            for value in row:
                if value_type == 'float':
                    print(f"{value:5.2f}", end="")
                    
                elif value_type == 'int':
                    print(f"{value:5d}", end="")
                    
                else: 
                    print(f"{0:5d}", end="")
            
           
            print()
    
    return 

def find_position(matrix):
    """
    -------------------------------------------------------
    Determines the first locations [row, column] of smallest and
    largest values in a 2D list.
    Use: s_loc, l_loc = find_position(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of numbers (2D list)
    Returns:
        s_loc - a list of of the row and column location of
            the smallest value in matrix (list of int)
        l_loc - a list of of the row and column location of
            the largest value in matrix (list of int)
    -------------------------------------------------------
    """
    
    
    if not matrix:
        min_loc = [0, 0]
        max_loc = [0, 0]
    
    else:
        rows = len(matrix)
        cols = len(matrix[0])
        min_val = matrix[0][0]
        max_val = matrix[0][0]
        min_loc = [0, 0]
        max_loc = [0, 0]
        
      
        for i in range(rows):
            for j in range(cols):
                
               
                if matrix[i][j] < min_val:
                    min_val = matrix[i][j]
                    min_loc = [i, j]
               
                elif matrix[i][j] > max_val:
                    max_val = matrix[i][j]
                    max_loc = [i, j]
    
    return min_loc, max_loc


def matrix_scalar_multiply(matrix, num):
    """
    -------------------------------------------------------
    Update matrix by multiplying each element of matrix by num.
    Use: matrix_scalar_multiply(matrix, num)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix to multiply (2D list of int/float)
        num - the number to multiply by (int/float)
    Returns:
        None
    ------------------------------------------------------
    """
    if not matrix:
        num = num
    
    else:
        rows = len(matrix)
        cols = len(matrix[0])
        
        for i in range(rows):
            for j in range(cols):
                matrix[i][j] = matrix[i][j] * num
        
    return

def matrix_transpose(matrix):
    """
    -------------------------------------------------------
    Transpose the contents of matrix. (Swap the rows and columns.)
    Use: transposed = matrix_transpose(matrix):
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list (2D list of *)
    Returns:
        transposed - the transposed matrix (2D list of *)
    ------------------------------------------------------
    """
    if not matrix:
        transposed = []
    
    else:
        rows = len(matrix)
        cols = len(matrix[0])
        transposed = [[None] * rows for k in range(cols)]
        
        for i in range(rows):
            for j in range(cols):
                transposed[j][i] = matrix[i][j]
        
    return transposed

def matrix_equal(matrix1, matrix2):
    """
    -------------------------------------------------------
    Compares two matrices to see if they are equal - i.e. have the
    same contents in the same locations.
    Use: equal = matrix_equal(matrix1, matrix2)
    -------------------------------------------------------
    Parameters:
        matrix1 - the first matrix (2D list of *)
        matrix2 - the second matrix (2D list of *)
    Returns:
        equal - True if matrix1 and matrix2 are equal,
            False otherwise (boolean)
    ------------------------------------------------------
    """
    if not matrix1:
        equal = False
    
    elif not matrix2:
        equal = False
    
    else: 
        rows1 = len(matrix1)
        rows2 = len(matrix2)
        cols1 = len(matrix1[0])
        cols2 = len(matrix2[0])
        equal = True
        
        if rows1 != rows2:
            equal = False
        
        elif cols1 != cols2:
            equal = False
            
        else:
            for j in range(rows1):
                for k in range(cols1):
                    if matrix1[j][k] == matrix2[j][k]:
                        equal = True
                    else:
                        equal = False
                    
    return equal


