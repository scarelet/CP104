"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""

from functions import generate_matrix_num


matrix_float = generate_matrix_num(3, 4, -10, 10,'float')

print(matrix_float)
    