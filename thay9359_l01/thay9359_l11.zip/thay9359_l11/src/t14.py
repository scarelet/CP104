"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""

from functions import matrix_transpose, print_matrix_num

matrix = [
    [9, 8, 7],
    [6, 5, 4],
    [3, 2, 1]
]
transposed = matrix_transpose(matrix)
print_matrix_num(transposed, 'int')

print()
