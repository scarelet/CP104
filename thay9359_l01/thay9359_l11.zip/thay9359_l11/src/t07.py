"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-12-01"
-------------------------------------------------------
"""


from functions import find_position

matrix = [
    [9, 8, 7],
    [6, 5, 4],
    [3, 2, 1]
]
s_loc, l_loc = find_position(matrix)
print(f"{s_loc}, {l_loc}")

print()

