"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Navina Thayaruban
ID:      169069359
Email:   thay9359@mylaurier.ca
__updated__ = "2023-11-25"
-------------------------------------------------------
"""

from functions import has_word_chain

result = has_word_chain(['camel', 'leopard', 'dog', 'giraffe', 'elephant'])


print(result)